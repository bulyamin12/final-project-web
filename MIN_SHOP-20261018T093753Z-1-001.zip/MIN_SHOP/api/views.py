from django.contrib.auth.models import User
from rest_framework import mixins, viewsets
from rest_framework.permissions import IsAdminUser, IsAuthenticated, IsAuthenticatedOrReadOnly

from orders.models import Order
from products.models import Category, Product

from .serializers import (
    CategorySerializer,
    OrderSerializer,
    ProductSerializer,
    UserSerializer,
)


class ProductViewSet(viewsets.ModelViewSet):
    """CRUD สินค้า: ทุกคนอ่านได้ แต่เขียน/แก้/ลบได้เฉพาะ Staff"""

    queryset = Product.objects.select_related("category")
    serializer_class = ProductSerializer

    def get_permissions(self):
        if self.action in ("list", "retrieve"):
            return [IsAuthenticatedOrReadOnly()]
        return [IsAdminUser()]

    def get_queryset(self):
        qs = super().get_queryset()
        if not self.request.user.is_staff:
            qs = qs.filter(status="active")
        return qs


class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    """ดูหมวดหมู่ (อ่านอย่างเดียว)"""

    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class OrderViewSet(
    mixins.CreateModelMixin,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    viewsets.GenericViewSet,
):
    """ออร์เดอร์: ดู (list/retrieve) และสร้าง (create) เท่านั้น ต้อง Login"""

    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = Order.objects.prefetch_related("items")
        # ลูกค้าเห็นเฉพาะของตัวเอง Staff เห็นทั้งหมด
        if not self.request.user.is_staff:
            qs = qs.filter(user=self.request.user)
        return qs


class UserViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    """ผู้ใช้: ลูกค้าเห็นเฉพาะตัวเอง Staff เห็นทุกคน"""

    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if self.request.user.is_staff:
            return User.objects.all().order_by("id")
        return User.objects.filter(pk=self.request.user.pk)