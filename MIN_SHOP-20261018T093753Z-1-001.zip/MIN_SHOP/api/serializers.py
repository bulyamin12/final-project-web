from django.contrib.auth.models import User
from django.db import transaction
from rest_framework import serializers

from cart.models import Cart
from orders.models import Order, OrderItem
from products.models import Category, Product


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name"]


class ProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source="category.name", read_only=True)
    final_price = serializers.DecimalField(
        max_digits=10, decimal_places=2, read_only=True
    )

    class Meta:
        model = Product
        fields = [
            "id",
            "name",
            "description",
            "price",
            "discount",
            "final_price",
            "stock",
            "category",
            "category_name",
            "brand",
            "status",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["created_at", "updated_at"]

    def validate_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("ชื่อสินค้าต้องไม่ว่าง")
        return value.strip()

    def validate_price(self, value):
        if value < 0:
            raise serializers.ValidationError("ราคาต้องไม่ติดลบ")
        return value


class UserSerializer(serializers.ModelSerializer):
    """ข้อมูลผู้ใช้ (ไม่รวมรหัสผ่าน)"""

    class Meta:
        model = User
        fields = ["id", "username", "email", "is_staff", "date_joined"]
        read_only_fields = fields


class OrderItemSerializer(serializers.ModelSerializer):
    subtotal = serializers.DecimalField(max_digits=12, decimal_places=2, read_only=True)

    class Meta:
        model = OrderItem
        fields = ["id", "product", "product_name", "price", "quantity", "subtotal"]
        read_only_fields = fields


class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = Order
        fields = [
            "id",
            "user",
            "full_name",
            "phone",
            "address",
            "total_price",
            "status",
            "status_display",
            "created_at",
            "items",
        ]
        # ผู้ใช้ส่งได้แค่ชื่อ เบอร์ ที่อยู่ ส่วนที่เหลือระบบเป็นคนกำหนดเอง
        read_only_fields = ["user", "total_price", "status", "created_at"]

    def validate_phone(self, value):
        digits = value.replace("-", "").replace(" ", "")
        if not digits.isdigit() or not (9 <= len(digits) <= 10):
            raise serializers.ValidationError("เบอร์โทรต้องเป็นตัวเลข 9-10 หลัก")
        return value

    def create(self, validated_data):
        """สร้าง Order จากตะกร้าของผู้ใช้ที่ Login อยู่"""
        user = self.context["request"].user
        cart = Cart.objects.filter(user=user).first()
        items = list(cart.items.select_related("product")) if cart else []

        if not items:
            raise serializers.ValidationError("ตะกร้าของคุณว่างอยู่")

        for item in items:
            if item.product.status != "active" or item.quantity > item.product.stock:
                raise serializers.ValidationError(
                    f"สินค้า {item.product.name} มีไม่พอ (เหลือ {item.product.stock} ชิ้น)"
                )

        with transaction.atomic():
            order = Order.objects.create(
                user=user, total_price=cart.total, **validated_data
            )
            for item in items:
                OrderItem.objects.create(
                    order=order,
                    product=item.product,
                    product_name=item.product.name,
                    price=item.product.final_price,
                    quantity=item.quantity,
                )
                item.product.stock -= item.quantity
                item.product.save()
            cart.items.all().delete()

        return order