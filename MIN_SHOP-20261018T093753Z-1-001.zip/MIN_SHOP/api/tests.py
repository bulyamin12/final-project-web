from decimal import Decimal

from django.contrib.auth.models import User
from rest_framework.test import APITestCase

from cart.models import Cart, CartItem
from orders.models import Order
from products.models import Category, Product


class ApiTests(APITestCase):
    def setUp(self):
        self.category = Category.objects.create(name="รองเท้า")
        self.product = Product.objects.create(
            name="nikky", price=Decimal("100"), stock=5, category=self.category
        )
        self.admin = User.objects.create_superuser("boss", "b@example.com", "AdminPass#2026")
        self.customer = User.objects.create_user("cust", "c@example.com", "CustPass#2026")

    def product_payload(self, **overrides):
        data = {
            "name": "เสื้อยืด",
            "price": "250.00",
            "discount": 0,
            "stock": 10,
            "category": self.category.pk,
            "status": "active",
        }
        data.update(overrides)
        return data

    def test_list_products_public(self):
        response = self.client.get("/api/products/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()), 1)

    def test_retrieve_product_and_404(self):
        self.assertEqual(self.client.get(f"/api/products/{self.product.pk}/").status_code, 200)
        self.assertEqual(self.client.get("/api/products/9999/").status_code, 404)

    def test_anonymous_cannot_create_product(self):
        response = self.client.post("/api/products/", self.product_payload(), format="json")
        self.assertIn(response.status_code, (401, 403))

    def test_customer_cannot_create_product(self):
        self.client.force_authenticate(self.customer)
        response = self.client.post("/api/products/", self.product_payload(), format="json")
        self.assertEqual(response.status_code, 403)

    def test_admin_create_update_delete_product(self):
        self.client.force_authenticate(self.admin)
        created = self.client.post("/api/products/", self.product_payload(), format="json")
        self.assertEqual(created.status_code, 201)
        pk = created.json()["id"]

        patched = self.client.patch(f"/api/products/{pk}/", {"stock": 20}, format="json")
        self.assertEqual(patched.status_code, 200)
        self.assertEqual(patched.json()["stock"], 20)

        deleted = self.client.delete(f"/api/products/{pk}/")
        self.assertEqual(deleted.status_code, 204)

    def test_negative_price_rejected(self):
        self.client.force_authenticate(self.admin)
        response = self.client.post(
            "/api/products/", self.product_payload(price="-5"), format="json"
        )
        self.assertEqual(response.status_code, 400)

    def test_orders_require_authentication(self):
        response = self.client.get("/api/orders/")
        self.assertIn(response.status_code, (401, 403))

    def test_customer_sees_only_own_orders(self):
        other = User.objects.create_user("other", password="OtherPass#2026")
        Order.objects.create(user=other, full_name="x", phone="0812345678", address="x", total_price=1)
        mine = Order.objects.create(user=self.customer, full_name="y", phone="0812345678", address="y", total_price=1)
        self.client.force_authenticate(self.customer)
        data = self.client.get("/api/orders/").json()
        self.assertEqual([o["id"] for o in data], [mine.pk])

    def test_create_order_ignores_client_price_and_status(self):
        """กันโกง: ราคาและสถานะที่ผู้ใช้ส่งมาต้องถูกเพิกเฉย"""
        cart = Cart.objects.create(user=self.customer)
        CartItem.objects.create(cart=cart, product=self.product, quantity=2)
        self.client.force_authenticate(self.customer)
        response = self.client.post(
            "/api/orders/",
            {
                "full_name": "สมชาย",
                "phone": "0812345678",
                "address": "ปัตตานี",
                "total_price": 1,
                "status": "delivered",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        body = response.json()
        self.assertEqual(body["total_price"], "200.00")
        self.assertEqual(body["status"], "pending")

    def test_users_endpoint_hides_password_and_other_users(self):
        self.client.force_authenticate(self.customer)
        data = self.client.get("/api/users/").json()
        self.assertEqual(len(data), 1)
        self.assertNotIn("password", data[0])