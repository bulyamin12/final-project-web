from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.models import User
from django.db.models import Sum
from django.shortcuts import render

from orders.models import Order
from products.models import Product


@staff_member_required
def dashboard(request):
    """หน้า Dashboard สำหรับ Admin (เข้าได้เฉพาะ Staff)"""
    # ยอดขาย = รวมทุก Order ที่ไม่ถูกยกเลิก
    sales = (
        Order.objects.exclude(status="cancelled")
        .aggregate(total=Sum("total_price"))["total"]
        or 0
    )

    context = {
        "product_count": Product.objects.count(),
        "customer_count": User.objects.filter(is_staff=False).count(),
        "order_count": Order.objects.count(),
        "total_sales": sales,
        "low_stock": Product.objects.filter(stock__lte=5).order_by("stock")[:5],
        "latest_orders": Order.objects.select_related("user")[:5],
        "latest_products": Product.objects.select_related("category")[:5],
    }
    return render(request, "dashboard/dashboard.html", context)