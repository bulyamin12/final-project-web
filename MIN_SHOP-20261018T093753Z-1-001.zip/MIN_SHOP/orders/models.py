from django.conf import settings
from django.db import models

from products.models import Product


class Order(models.Model):
    """คำสั่งซื้อ"""

    STATUS_CHOICES = [
        ("pending", "Pending (รอดำเนินการ)"),
        ("processing", "Processing (กำลังเตรียมสินค้า)"),
        ("shipped", "Shipped (จัดส่งแล้ว)"),
        ("delivered", "Delivered (ส่งสำเร็จ)"),
        ("cancelled", "Cancelled (ยกเลิก)"),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="orders",
        verbose_name="ลูกค้า",
    )
    full_name = models.CharField("ชื่อผู้รับ", max_length=150)
    phone = models.CharField("เบอร์โทร", max_length=20)
    address = models.TextField("ที่อยู่จัดส่ง")
    total_price = models.DecimalField("ยอดรวม", max_digits=12, decimal_places=2, default=0)
    status = models.CharField(
        "สถานะ", max_length=20, choices=STATUS_CHOICES, default="pending"
    )
    created_at = models.DateTimeField("วันที่สั่งซื้อ", auto_now_add=True)

    class Meta:
        verbose_name = "คำสั่งซื้อ"
        verbose_name_plural = "คำสั่งซื้อ"
        ordering = ["-created_at"]

    def __str__(self):
        return f"Order #{self.pk} - {self.user.username}"


class OrderItem(models.Model):
    """รายการสินค้าใน Order (เก็บชื่อและราคา ณ ตอนซื้อ)"""

    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name="items",
        verbose_name="คำสั่งซื้อ",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="สินค้า",
    )
    product_name = models.CharField("ชื่อสินค้า (ตอนซื้อ)", max_length=200)
    price = models.DecimalField("ราคาต่อชิ้น (ตอนซื้อ)", max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField("จำนวน", default=1)

    class Meta:
        verbose_name = "รายการในคำสั่งซื้อ"
        verbose_name_plural = "รายการในคำสั่งซื้อ"

    def __str__(self):
        return f"{self.product_name} x {self.quantity}"

    @property
    def subtotal(self):
        if self.price is None:
            return 0
        return self.price * self.quantity