from django import forms

from .models import Order


class CheckoutForm(forms.ModelForm):
    """ฟอร์มข้อมูลจัดส่ง"""

    class Meta:
        model = Order
        fields = ("full_name", "phone", "address")
        widgets = {
            "full_name": forms.TextInput(attrs={"class": "form-control"}),
            "phone": forms.TextInput(attrs={"class": "form-control"}),
            "address": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }

    def clean_phone(self):
        phone = self.cleaned_data["phone"].strip()
        digits = phone.replace("-", "").replace(" ", "")
        if not digits.isdigit() or not (9 <= len(digits) <= 10):
            raise forms.ValidationError("เบอร์โทรต้องเป็นตัวเลข 9-10 หลัก")
        return phone