from django.contrib import admin

from .models import Order, OrderItem


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ("subtotal",)


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "full_name", "total_price", "status", "created_at")
    list_filter = ("status", "created_at")
    search_fields = ("id", "user__username", "full_name", "phone")
    list_editable = ("status",)
    ordering = ("-created_at",)
    inlines = [OrderItemInline]