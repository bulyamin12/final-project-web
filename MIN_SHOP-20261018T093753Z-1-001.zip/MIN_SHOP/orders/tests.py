from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from cart.models import Cart, CartItem
from products.models import Category, Product

from .models import Order


class OrderFlowTests(TestCase):
    """Integration Test: ตะกร้า -> Checkout -> Order"""

    def setUp(self):
        self.user = User.objects.create_user("buyer", password="BuyerPass#2026")
        category = Category.objects.create(name="รองเท้า")
        self.product = Product.objects.create(
            name="nikky", price=Decimal("100"), discount=10, stock=5, category=category
        )
        self.client.login(username="buyer", password="BuyerPass#2026")
        cart = Cart.objects.create(user=self.user)
        CartItem.objects.create(cart=cart, product=self.product, quantity=2)

    def valid_data(self, **overrides):
        data = {"full_name": "สมชาย", "phone": "0812345678", "address": "ปัตตานี"}
        data.update(overrides)
        return data

    def test_create_order(self):
        response = self.client.post(reverse("checkout"), self.valid_data())
        order = Order.objects.get(user=self.user)
        self.assertRedirects(response, reverse("order_detail", args=[order.pk]))
        self.assertEqual(order.status, "pending")
        self.assertEqual(order.total_price, Decimal("180.00"))  # 90 x 2

    def test_stock_reduced_and_cart_cleared(self):
        self.client.post(reverse("checkout"), self.valid_data())
        self.product.refresh_from_db()
        self.assertEqual(self.product.stock, 3)  # 5 - 2
        self.assertEqual(CartItem.objects.filter(cart__user=self.user).count(), 0)

    def test_invalid_phone_rejected(self):
        self.client.post(reverse("checkout"), self.valid_data(phone="abc"))
        self.assertEqual(Order.objects.count(), 0)

    def test_empty_cart_cannot_checkout(self):
        CartItem.objects.all().delete()
        self.client.post(reverse("checkout"), self.valid_data())
        self.assertEqual(Order.objects.count(), 0)

    def test_cannot_view_other_users_order(self):
        """Permission: ดูออร์เดอร์ของคนอื่นไม่ได้"""
        other = User.objects.create_user("other", password="OtherPass#2026")
        order = Order.objects.create(
            user=other, full_name="x", phone="0812345678", address="x", total_price=1
        )
        response = self.client.get(reverse("order_detail", args=[order.pk]))
        self.assertEqual(response.status_code, 404)