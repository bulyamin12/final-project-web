from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render

from cart.models import Cart

from .forms import CheckoutForm
from .models import Order, OrderItem


@login_required
def checkout(request):
    """หน้ายืนยันการสั่งซื้อ: แปลงตะกร้าเป็น Order"""
    cart = Cart.objects.filter(user=request.user).first()
    items = cart.items.select_related("product") if cart else []

    if not items:
        messages.warning(request, "ตะกร้าของคุณว่างอยู่")
        return redirect("cart_detail")

    if request.method == "POST":
        form = CheckoutForm(request.POST)
        if form.is_valid():
            # ตรวจสต็อกก่อนสร้าง Order
            for item in items:
                if item.product.status != "active" or item.quantity > item.product.stock:
                    messages.error(
                        request,
                        f"สินค้า {item.product.name} มีไม่พอ (เหลือ {item.product.stock} ชิ้น) กรุณาแก้จำนวนในตะกร้า",
                    )
                    return redirect("cart_detail")

            # ทำทุกขั้นตอนเป็นก้อนเดียว ถ้าพังจะยกเลิกทั้งหมด
            with transaction.atomic():
                order = form.save(commit=False)
                order.user = request.user
                order.total_price = cart.total
                order.save()

                for item in items:
                    OrderItem.objects.create(
                        order=order,
                        product=item.product,
                        product_name=item.product.name,
                        price=item.product.final_price,
                        quantity=item.quantity,
                    )
                    # ตัดสต็อก
                    item.product.stock -= item.quantity
                    item.product.save()

                # ล้างตะกร้า
                cart.items.all().delete()

            messages.success(request, f"สั่งซื้อสำเร็จ! หมายเลขคำสั่งซื้อ #{order.pk}")
            return redirect("order_detail", pk=order.pk)
    else:
        profile = getattr(request.user, "profile", None)
        form = CheckoutForm(
            initial={
                "full_name": request.user.get_full_name(),
                "phone": profile.phone if profile else "",
                "address": profile.address if profile else "",
            }
        )

    return render(
        request, "orders/checkout.html", {"form": form, "cart": cart, "items": items}
    )


@login_required
def order_list(request):
    """ประวัติคำสั่งซื้อของฉัน"""
    orders = Order.objects.filter(user=request.user)
    return render(request, "orders/order_list.html", {"orders": orders})


@login_required
def order_detail(request, pk):
    """รายละเอียดคำสั่งซื้อ (ดูได้เฉพาะของตัวเอง)"""
    order = get_object_or_404(Order, pk=pk, user=request.user)
    return render(request, "orders/order_detail.html", {"order": order})