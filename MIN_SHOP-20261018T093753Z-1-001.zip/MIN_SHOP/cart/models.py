from django.conf import settings
from django.db import models

from products.models import Product


class Cart(models.Model):
    """ตะกร้าสินค้า: 1 ผู้ใช้ มี 1 ตะกร้า"""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="cart",
        verbose_name="ผู้ใช้",
    )
    created_at = models.DateTimeField("วันที่สร้าง", auto_now_add=True)

    class Meta:
        verbose_name = "ตะกร้า"
        verbose_name_plural = "ตะกร้า"

    def __str__(self):
        return f"ตะกร้าของ {self.user.username}"

    @property
    def total(self):
        """ยอดรวมทั้งตะกร้า"""
        return sum(item.subtotal for item in self.items.all())

    @property
    def total_items(self):
        """จำนวนชิ้นรวมทั้งตะกร้า"""
        return sum(item.quantity for item in self.items.all())


class CartItem(models.Model):
    """รายการสินค้าในตะกร้า"""

    cart = models.ForeignKey(
        Cart,
        on_delete=models.CASCADE,
        related_name="items",
        verbose_name="ตะกร้า",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        verbose_name="สินค้า",
    )
    quantity = models.PositiveIntegerField("จำนวน", default=1)

    class Meta:
        verbose_name = "รายการในตะกร้า"
        verbose_name_plural = "รายการในตะกร้า"
        constraints = [
            # สินค้าชนิดเดียวกันอยู่ในตะกร้าเดียวกันได้แค่ 1 แถว
            models.UniqueConstraint(
                fields=["cart", "product"], name="unique_product_per_cart"
            )
        ]

    def __str__(self):
        return f"{self.product.name} x {self.quantity}"

    @property
    def subtotal(self):
        """ราคารวมของรายการนี้ = ราคาหลังลด x จำนวน"""
        return self.product.final_price * self.quantity