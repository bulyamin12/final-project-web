from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from products.models import Category, Product

from .models import Cart, CartItem


class CartTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user("buyer", password="BuyerPass#2026")
        category = Category.objects.create(name="รองเท้า")
        self.product = Product.objects.create(
            name="nikky", price=Decimal("100"), stock=5, category=category
        )
        self.client.login(username="buyer", password="BuyerPass#2026")

    def test_add_to_cart(self):
        self.client.post(reverse("add_to_cart", args=[self.product.pk]), {"quantity": 2})
        item = CartItem.objects.get(cart__user=self.user, product=self.product)
        self.assertEqual(item.quantity, 2)

    def test_subtotal_and_total(self):
        """ราคา 100 x 2 = 200 (ตัวอย่างในโจทย์)"""
        self.client.post(reverse("add_to_cart", args=[self.product.pk]), {"quantity": 2})
        cart = Cart.objects.get(user=self.user)
        self.assertEqual(cart.items.first().subtotal, Decimal("200.00"))
        self.assertEqual(cart.total, Decimal("200.00"))

    def test_cannot_exceed_stock(self):
        self.client.post(reverse("add_to_cart", args=[self.product.pk]), {"quantity": 99})
        item = CartItem.objects.get(cart__user=self.user)
        self.assertEqual(item.quantity, 5)  # ถูกจำกัดตามสต็อก

    def test_remove_item(self):
        self.client.post(reverse("add_to_cart", args=[self.product.pk]), {"quantity": 1})
        item = CartItem.objects.get(cart__user=self.user)
        self.client.post(reverse("remove_item", args=[item.pk]))
        self.assertFalse(CartItem.objects.filter(pk=item.pk).exists())

    def test_cart_requires_login(self):
        self.client.logout()
        response = self.client.get(reverse("cart_detail"))
        self.assertEqual(response.status_code, 302)

    def test_cannot_remove_other_users_item(self):
        """Permission: ห้ามลบของในตะกร้าคนอื่น"""
        other = User.objects.create_user("other", password="OtherPass#2026")
        other_cart = Cart.objects.create(user=other)
        other_item = CartItem.objects.create(cart=other_cart, product=self.product, quantity=1)
        response = self.client.post(reverse("remove_item", args=[other_item.pk]))
        self.assertEqual(response.status_code, 404)
        self.assertTrue(CartItem.objects.filter(pk=other_item.pk).exists())