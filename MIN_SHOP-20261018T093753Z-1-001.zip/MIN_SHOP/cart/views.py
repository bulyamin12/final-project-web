from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from products.models import Product

from .models import Cart, CartItem


def get_user_cart(user):
    """ดึงตะกร้าของผู้ใช้ ถ้ายังไม่มีให้สร้างใหม่"""
    cart, _ = Cart.objects.get_or_create(user=user)
    return cart


@login_required
def cart_detail(request):
    """หน้าตะกร้าสินค้า"""
    cart = get_user_cart(request.user)
    items = cart.items.select_related("product")
    return render(request, "cart/cart.html", {"cart": cart, "items": items})


@login_required
@require_POST
def add_to_cart(request, product_id):
    """เพิ่มสินค้าลงตะกร้า"""
    product = get_object_or_404(Product, pk=product_id, status="active")

    # อ่านจำนวนจากฟอร์ม ถ้าไม่ใช่ตัวเลขให้ใช้ 1
    try:
        quantity = int(request.POST.get("quantity", 1))
    except ValueError:
        quantity = 1
    quantity = max(quantity, 1)

    cart = get_user_cart(request.user)
    item, created = CartItem.objects.get_or_create(
        cart=cart, product=product, defaults={"quantity": 0}
    )

    # ห้ามเกินจำนวนในสต็อก
    new_quantity = item.quantity + quantity
    if new_quantity > product.stock:
        new_quantity = product.stock
        messages.warning(request, f"สินค้า {product.name} เหลือในสต็อกเพียง {product.stock} ชิ้น")
    else:
        messages.success(request, f"เพิ่ม {product.name} ลงตะกร้าแล้ว")

    if new_quantity <= 0:
        item.delete()
        messages.error(request, "สินค้าหมด ไม่สามารถเพิ่มลงตะกร้าได้")
    else:
        item.quantity = new_quantity
        item.save()

    # ถ้ากด "ซื้อเลย" ให้ไปหน้าตะกร้าทันที
    if request.POST.get("buy_now"):
        return redirect("cart_detail")
    return redirect("product_detail", pk=product.pk)


@login_required
@require_POST
def update_quantity(request, item_id, action):
    """เพิ่ม/ลดจำนวนสินค้าในตะกร้า (action = increase หรือ decrease)"""
    item = get_object_or_404(CartItem, pk=item_id, cart__user=request.user)

    if action == "increase":
        if item.quantity < item.product.stock:
            item.quantity += 1
            item.save()
        else:
            messages.warning(request, f"สินค้า {item.product.name} เหลือในสต็อกเพียง {item.product.stock} ชิ้น")
    elif action == "decrease":
        if item.quantity > 1:
            item.quantity -= 1
            item.save()
        else:
            item.delete()
            messages.success(request, "ลบสินค้าออกจากตะกร้าแล้ว")

    return redirect("cart_detail")


@login_required
@require_POST
def remove_item(request, item_id):
    """ลบสินค้าออกจากตะกร้า"""
    item = get_object_or_404(CartItem, pk=item_id, cart__user=request.user)
    item.delete()
    messages.success(request, "ลบสินค้าออกจากตะกร้าแล้ว")
    return redirect("cart_detail")