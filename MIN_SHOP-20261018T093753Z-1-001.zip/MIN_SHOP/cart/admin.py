from django.contrib import admin

from .models import Cart, CartItem


class CartItemInline(admin.TabularInline):
    """แสดงรายการสินค้าในหน้าแก้ไขตะกร้า"""

    model = CartItem
    extra = 0


@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ("user", "total_items", "total", "created_at")
    search_fields = ("user__username",)
    inlines = [CartItemInline]