def cart_count(request):
    """ส่งจำนวนสินค้าในตะกร้าไปทุกหน้า"""
    count = 0
    if request.user.is_authenticated:
        cart = getattr(request.user, "cart", None)
        if cart:
            count = cart.total_items
    return {"cart_count": count}