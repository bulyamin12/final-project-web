from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse


class AuthTests(TestCase):
    def test_register_success(self):
        """สมัครสมาชิกสำเร็จ และ Login ให้อัตโนมัติ"""
        response = self.client.post(
            reverse("register"),
            {
                "username": "newuser",
                "email": "new@example.com",
                "password1": "StrongPass#2026",
                "password2": "StrongPass#2026",
            },
        )
        self.assertRedirects(response, reverse("home"))
        self.assertTrue(User.objects.filter(username="newuser").exists())

    def test_register_password_is_hashed(self):
        """รหัสผ่านต้องถูกเข้ารหัส ไม่เก็บเป็นข้อความตรง ๆ"""
        self.client.post(
            reverse("register"),
            {
                "username": "hashuser",
                "email": "hash@example.com",
                "password1": "StrongPass#2026",
                "password2": "StrongPass#2026",
            },
        )
        user = User.objects.get(username="hashuser")
        self.assertNotEqual(user.password, "StrongPass#2026")
        self.assertTrue(user.password.startswith("pbkdf2_sha256$"))

    def test_register_invalid_email(self):
        """อีเมลผิดรูปแบบต้องสมัครไม่ได้ (Validation)"""
        response = self.client.post(
            reverse("register"),
            {
                "username": "bademail",
                "email": "not-an-email",
                "password1": "StrongPass#2026",
                "password2": "StrongPass#2026",
            },
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(User.objects.filter(username="bademail").exists())

    def test_register_duplicate_email(self):
        """อีเมลซ้ำต้องสมัครไม่ได้"""
        User.objects.create_user("first", "dup@example.com", "StrongPass#2026")
        self.client.post(
            reverse("register"),
            {
                "username": "second",
                "email": "dup@example.com",
                "password1": "StrongPass#2026",
                "password2": "StrongPass#2026",
            },
        )
        self.assertFalse(User.objects.filter(username="second").exists())

    def test_login_success(self):
        User.objects.create_user("loginuser", password="StrongPass#2026")
        response = self.client.post(
            reverse("login"),
            {"username": "loginuser", "password": "StrongPass#2026"},
        )
        self.assertRedirects(response, reverse("home"))

    def test_login_wrong_password(self):
        User.objects.create_user("loginuser", password="StrongPass#2026")
        response = self.client.post(
            reverse("login"),
            {"username": "loginuser", "password": "wrong"},
        )
        self.assertEqual(response.status_code, 200)  # อยู่หน้าเดิม ไม่ผ่าน
        self.assertNotIn("_auth_user_id", self.client.session)