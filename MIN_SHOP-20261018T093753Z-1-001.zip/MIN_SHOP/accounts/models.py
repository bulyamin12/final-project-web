from django.conf import settings
from django.db import models


class Profile(models.Model):
    """ข้อมูลเพิ่มเติมของผู้ใช้ (1 ผู้ใช้ มี 1 โปรไฟล์)"""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="profile",
        verbose_name="ผู้ใช้",
    )
    phone = models.CharField("เบอร์โทร", max_length=20, blank=True)
    address = models.TextField("ที่อยู่", blank=True)

    class Meta:
        verbose_name = "โปรไฟล์"
        verbose_name_plural = "โปรไฟล์"

    def __str__(self):
        return f"โปรไฟล์ของ {self.user.username}"