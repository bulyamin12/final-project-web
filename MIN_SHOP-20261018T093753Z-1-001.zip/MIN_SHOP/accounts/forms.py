from django import forms
from .models import Profile
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class RegisterForm(UserCreationForm):
    """ฟอร์มสมัครสมาชิก: เพิ่มช่อง Email ที่ต้องกรอก"""

    email = forms.EmailField(label="อีเมล", required=True)

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")

    def clean_email(self):
        email = self.cleaned_data["email"]
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("อีเมลนี้ถูกใช้งานแล้ว")
        return email

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # ใส่ class ของ Bootstrap ให้ทุกช่อง
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"
            

class UserUpdateForm(forms.ModelForm):
    """แก้ไขชื่อผู้ใช้ ชื่อ-นามสกุล และอีเมล"""

    email = forms.EmailField(label="อีเมล", required=True)

    class Meta:
        model = User
        fields = ("username", "first_name", "last_name", "email")
        labels = {
            "username": "ชื่อผู้ใช้",
            "first_name": "ชื่อ",
            "last_name": "นามสกุล",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs["class"] = "form-control"

    def clean_email(self):
        email = self.cleaned_data["email"]
        # อีเมลซ้ำกับคนอื่นไม่ได้ (ไม่นับตัวเอง)
        if User.objects.filter(email__iexact=email).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError("อีเมลนี้ถูกใช้งานแล้ว")
        return email


class ProfileForm(forms.ModelForm):
    """แก้ไขเบอร์โทรและที่อยู่"""

    class Meta:
        model = Profile
        fields = ("phone", "address")
        widgets = {
            "phone": forms.TextInput(attrs={"class": "form-control"}),
            "address": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }

    def clean_phone(self):
        phone = self.cleaned_data["phone"].strip()
        if not phone:
            return phone
        digits = phone.replace("-", "").replace(" ", "")
        if not digits.isdigit() or not (9 <= len(digits) <= 10):
            raise forms.ValidationError("เบอร์โทรต้องเป็นตัวเลข 9-10 หลัก")
        return phone