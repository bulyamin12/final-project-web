from django import forms

from .models import Review


class ReviewForm(forms.ModelForm):
    """ฟอร์มรีวิวสินค้า"""

    class Meta:
        model = Review
        fields = ("rating", "comment")
        widgets = {
            "rating": forms.Select(
                choices=[(5, "5 ดาว"), (4, "4 ดาว"), (3, "3 ดาว"), (2, "2 ดาว"), (1, "1 ดาว")],
                attrs={"class": "form-select"},
            ),
            "comment": forms.Textarea(
                attrs={"class": "form-control", "rows": 3, "placeholder": "เล่าประสบการณ์การใช้สินค้า..."}
            ),
        }