from decimal import Decimal
from datetime import timedelta

from django.utils import timezone

from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse

from .models import Category, Product, Promotion, Review

def make_product(category, **kwargs):
    data = {"name": "รองเท้าทดสอบ", "price": Decimal("100"), "stock": 10}
    data.update(kwargs)
    return Product.objects.create(category=category, **data)


class ProductModelTests(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name="รองเท้า")

    def test_final_price_with_discount(self):
        """ราคา 200 ลด 10% ต้องเหลือ 180"""
        p = make_product(self.category, price=Decimal("200"), discount=10)
        self.assertEqual(p.final_price, Decimal("180.00"))

    def test_negative_price_rejected(self):
        """ราคาติดลบต้องไม่ผ่าน Validation"""
        p = Product(name="x", price=Decimal("-5"), stock=1, category=self.category)
        with self.assertRaises(ValidationError):
            p.full_clean()

    def test_empty_name_rejected(self):
        p = Product(name="", price=Decimal("5"), stock=1, category=self.category)
        with self.assertRaises(ValidationError):
            p.full_clean()

    def test_discount_over_100_rejected(self):
        p = Product(
            name="x", price=Decimal("5"), stock=1, discount=150, category=self.category
        )
        with self.assertRaises(ValidationError):
            p.full_clean()


class ProductViewTests(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name="รองเท้า")
        self.product = make_product(self.category, name="nikky")

    def test_product_list(self):
        response = self.client.get(reverse("product_list"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "nikky")

    def test_search_found_and_not_found(self):
        found = self.client.get(reverse("product_list"), {"q": "nikky"})
        self.assertContains(found, "nikky")
        missing = self.client.get(reverse("product_list"), {"q": "zzzz"})
        self.assertNotContains(missing, "nikky")

    def test_product_detail(self):
        response = self.client.get(reverse("product_detail", args=[self.product.pk]))
        self.assertEqual(response.status_code, 200)

    def test_product_detail_404(self):
        response = self.client.get(reverse("product_detail", args=[9999]))
        self.assertEqual(response.status_code, 404)

    def test_inactive_product_hidden(self):
        """สินค้าปิดขายต้องไม่แสดงในรายการ"""
        make_product(self.category, name="ซ่อนอยู่", status="inactive")
        response = self.client.get(reverse("product_list"))
        self.assertNotContains(response, "ซ่อนอยู่")

    def test_wishlist_requires_login(self):
        response = self.client.get(reverse("wishlist"))
        self.assertEqual(response.status_code, 302)  # ถูกพาไปหน้า Login


class AdminPermissionTests(TestCase):
    """Product Create / Update / Delete ผ่านหน้า Django Admin และสิทธิ์การเข้าถึง"""

    def setUp(self):
        self.category = Category.objects.create(name="รองเท้า")
        self.admin = User.objects.create_superuser("boss", "boss@example.com", "AdminPass#2026")
        self.customer = User.objects.create_user("cust", "c@example.com", "CustPass#2026")

    def test_admin_can_create_product(self):
        self.client.login(username="boss", password="AdminPass#2026")
        response = self.client.post(
            reverse("admin:products_product_add"),
            {
                "name": "สินค้าใหม่",
                "description": "",
                "price": "99.00",
                "discount": 0,
                "stock": 5,
                "category": self.category.pk,
                "brand": "",
                "status": "active",
            },
        )
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Product.objects.filter(name="สินค้าใหม่").exists())

    def test_admin_can_update_product(self):
        product = make_product(self.category)
        self.client.login(username="boss", password="AdminPass#2026")
        self.client.post(
            reverse("admin:products_product_change", args=[product.pk]),
            {
                "name": "ชื่อใหม่",
                "description": "",
                "price": "120.00",
                "discount": 0,
                "stock": 7,
                "category": self.category.pk,
                "brand": "",
                "status": "active",
            },
        )
        product.refresh_from_db()
        self.assertEqual(product.name, "ชื่อใหม่")
        self.assertEqual(product.stock, 7)

    def test_admin_can_delete_product(self):
        product = make_product(self.category)
        self.client.login(username="boss", password="AdminPass#2026")
        self.client.post(
            reverse("admin:products_product_delete", args=[product.pk]),
            {"post": "yes"},
        )
        self.assertFalse(Product.objects.filter(pk=product.pk).exists())

    def test_customer_cannot_access_admin(self):
        self.client.login(username="cust", password="CustPass#2026")
        response = self.client.get(reverse("admin:products_product_changelist"))
        self.assertEqual(response.status_code, 302)  # ถูกพาไปหน้า Login Admin

    def test_customer_cannot_access_dashboard(self):
        self.client.login(username="cust", password="CustPass#2026")
        response = self.client.get(reverse("dashboard"))
        self.assertEqual(response.status_code, 302)

    def test_admin_can_access_dashboard(self):
        self.client.login(username="boss", password="AdminPass#2026")
        response = self.client.get(reverse("dashboard"))
        self.assertEqual(response.status_code, 200)
        

class HomePageTests(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name="รองเท้า")

    def test_home_empty_state(self):
        """ยังไม่มีสินค้า หน้าแรกต้องไม่พัง"""
        response = self.client.get(reverse("home"))
        self.assertEqual(response.status_code, 200)

    def test_home_sections_with_data(self):
        """มีส่วนลด ยอดขาย และรีวิว ทุกส่วนต้องแสดงผลได้"""
        from orders.models import Order, OrderItem

        user = User.objects.create_user("buyer", password="BuyerPass#2026")
        product = make_product(self.category, name="ขายดีมาก", discount=20)
        order = Order.objects.create(
            user=user, full_name="x", phone="0812345678", address="x", total_price=1
        )
        OrderItem.objects.create(
            order=order, product=product, product_name=product.name, price=1, quantity=3
        )
        Review.objects.create(
            product=product, user=user, rating=5, comment="ใช้ดีมากเลยครับ"
        )

        response = self.client.get(reverse("home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "FLASH SALE")
        self.assertContains(response, "สินค้าขายดี")
        self.assertContains(response, "เสียงจากลูกค้า")
        self.assertContains(response, "ใช้ดีมากเลยครับ")

    def test_cancelled_orders_not_counted_as_best_seller(self):
        from orders.models import Order, OrderItem

        user = User.objects.create_user("buyer", password="BuyerPass#2026")
        product = make_product(self.category, name="ยกเลิกแล้ว")
        order = Order.objects.create(
            user=user,
            full_name="x",
            phone="0812345678",
            address="x",
            total_price=1,
            status="cancelled",
        )
        OrderItem.objects.create(
            order=order, product=product, product_name=product.name, price=1, quantity=5
        )
        response = self.client.get(reverse("home"))
        self.assertNotContains(response, "สินค้าขายดี")
        

class FilterSortTests(TestCase):
    def setUp(self):
        self.shoes = Category.objects.create(name="รองเท้า")
        self.bags = Category.objects.create(name="กระเป๋า")
        make_product(self.shoes, name="ถูก", price=Decimal("100"), brand="A")
        make_product(self.shoes, name="แพง", price=Decimal("900"), brand="B")
        make_product(self.bags, name="ลดราคา", price=Decimal("1000"), discount=50, brand="A")
        make_product(self.bags, name="หมดแล้ว", price=Decimal("300"), stock=0, brand="B")

    def names(self, response):
        return [p.name for p in response.context["products"]]

    def test_sort_price_asc_and_desc(self):
        asc = self.names(self.client.get(reverse("product_list"), {"sort": "price_asc"}))
        self.assertEqual(asc[0], "ถูก")  # 100
        desc = self.names(self.client.get(reverse("product_list"), {"sort": "price_desc"}))
        self.assertEqual(desc[0], "แพง")  # 900 (ลดราคา = 500)

    def test_filter_uses_discounted_price(self):
        """ราคา 1000 ลด 50% = 500 ต้องอยู่ในช่วง 400-600"""
        result = self.names(
            self.client.get(reverse("product_list"), {"min_price": "400", "max_price": "600"})
        )
        self.assertEqual(result, ["ลดราคา"])

    def test_filter_brand_and_category(self):
        result = self.names(self.client.get(reverse("product_list"), {"brand": "A"}))
        self.assertCountEqual(result, ["ถูก", "ลดราคา"])
        result = self.names(
            self.client.get(reverse("product_list"), {"category": self.bags.pk})
        )
        self.assertCountEqual(result, ["ลดราคา", "หมดแล้ว"])

    def test_filter_in_stock(self):
        result = self.names(self.client.get(reverse("product_list"), {"in_stock": "1"}))
        self.assertNotIn("หมดแล้ว", result)

    def test_invalid_input_does_not_crash(self):
        response = self.client.get(
            reverse("product_list"),
            {"min_price": "abc", "sort": "hack", "min_rating": "99", "category": "x"},
        )
        self.assertEqual(response.status_code, 200)
        

class PromotionTests(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name="รองเท้า")
        self.product = make_product(self.category, name="สินค้าโปร")

    def make_promo(self, start_delta, end_delta, **kwargs):
        now = timezone.now()
        promo = Promotion.objects.create(
            title=kwargs.pop("title", "โปรทดสอบ"),
            start_at=now + timedelta(hours=start_delta),
            end_at=now + timedelta(hours=end_delta),
            **kwargs,
        )
        promo.products.add(self.product)
        return promo

    def test_running_promotion_shown_on_home(self):
        self.make_promo(-1, 5, title="โปรกำลังมา")
        response = self.client.get(reverse("home"))
        self.assertContains(response, "โปรกำลังมา")
        self.assertContains(response, "สินค้าโปร")

    def test_expired_and_future_promotion_not_shown(self):
        self.make_promo(-10, -5, title="โปรหมดอายุ")
        self.make_promo(5, 10, title="โปรยังไม่เริ่ม")
        response = self.client.get(reverse("home"))
        self.assertNotContains(response, "โปรหมดอายุ")
        self.assertNotContains(response, "โปรยังไม่เริ่ม")

    def test_inactive_promotion_not_shown(self):
        self.make_promo(-1, 5, title="โปรปิดอยู่", is_active=False)
        response = self.client.get(reverse("home"))
        self.assertNotContains(response, "โปรปิดอยู่")

    def test_end_before_start_rejected(self):
        from django.core.exceptions import ValidationError

        now = timezone.now()
        promo = Promotion(title="ผิด", start_at=now, end_at=now - timedelta(hours=1))
        with self.assertRaises(ValidationError):
            promo.full_clean()