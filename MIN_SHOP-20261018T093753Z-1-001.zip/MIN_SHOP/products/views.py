from django.contrib import messages
from decimal import Decimal, InvalidOperation
from django.contrib.auth.decorators import login_required
from django.db.models import Avg, Count, DecimalField, ExpressionWrapper, F, Q, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from orders.models import OrderItem

from .forms import ReviewForm
from .models import Category, Product, Promotion, Review, Wishlist


def home(request):
    """หน้าแรก: Flash Sale (ตามโปรโมชัน), Popular, Best Sellers, รีวิวล่าสุด"""
    active = Product.objects.filter(status="active").select_related("category")

    # Flash Sale: ใช้โปรโมชันที่กำลังดำเนินการ ถ้าไม่มีให้ใช้สินค้าที่มีส่วนลด
    now = timezone.now()
    promotion = (
        Promotion.objects.filter(is_active=True, start_at__lte=now, end_at__gte=now)
        .order_by("end_at")
        .first()
    )
    if promotion:
        flash_products = promotion.products.filter(status="active", stock__gt=0)[:4]
    else:
        flash_products = active.filter(discount__gt=0, stock__gt=0).order_by("-discount")[:4]

    # Popular: จำนวนคนกดรายการโปรด + จำนวนรีวิว
    popular_products = (
        active.annotate(
            score=Count("wishlisted_by", distinct=True) + Count("reviews", distinct=True)
        )
        .filter(score__gt=0)
        .order_by("-score")[:4]
    )

    # Best Sellers: จำนวนชิ้นที่ขายได้ (ไม่นับ Order ที่ยกเลิก)
    best_sellers = (
        active.annotate(
            sold=Sum(
                "orderitem__quantity",
                filter=Q(
                    orderitem__order__status__in=[
                        "pending",
                        "processing",
                        "shipped",
                        "delivered",
                    ]
                ),
            )
        )
        .filter(sold__gt=0)
        .order_by("-sold")[:4]
    )

    # รีวิวล่าสุดที่มีข้อความ
    latest_reviews = (
        Review.objects.filter(product__status="active")
        .exclude(comment="")
        .select_related("user", "product")[:3]
    )

    context = {
        "products": active[:8],
        "categories": Category.objects.all(),
        "promotion": promotion,
        "flash_products": flash_products,
        "popular_products": popular_products,
        "best_sellers": best_sellers,
        "latest_reviews": latest_reviews,
    }
    return render(request, "home.html", context)


def product_list(request):
    """รายการสินค้า: ค้นหา กรอง (หมวด ราคา แบรนด์ เรตติ้ง สต็อก) และเรียงลำดับ"""
    products = (
        Product.objects.filter(status="active")
        .select_related("category")
        .annotate(
            # ราคาหลังลด คำนวณใน Database เพื่อกรองและเรียงได้
            sale_price=ExpressionWrapper(
                F("price") * (100 - F("discount")) / 100,
                output_field=DecimalField(max_digits=10, decimal_places=2),
            ),
            avg_rating=Avg("reviews__rating"),
            popularity=Count("wishlisted_by", distinct=True)
            + Count("reviews", distinct=True),
        )
    )

    # ค้นหา
    q = request.GET.get("q", "").strip()
    if q:
        products = products.filter(Q(name__icontains=q) | Q(brand__icontains=q))

    # หมวดหมู่
    category_id = request.GET.get("category", "")
    if category_id.isdigit():
        products = products.filter(category_id=int(category_id))

    # แบรนด์
    brand = request.GET.get("brand", "").strip()
    if brand:
        products = products.filter(brand=brand)

    # ช่วงราคา (ราคาหลังลด) รับเฉพาะตัวเลข
    for key, lookup in (("min_price", "sale_price__gte"), ("max_price", "sale_price__lte")):
        value = request.GET.get(key, "").strip()
        try:
            if value:
                products = products.filter(**{lookup: Decimal(value)})
        except InvalidOperation:
            pass

    # เรตติ้งขั้นต่ำ
    min_rating = request.GET.get("min_rating", "")
    if min_rating in ("1", "2", "3", "4", "5"):
        products = products.filter(avg_rating__gte=int(min_rating))

    # เฉพาะสินค้าที่มีของ
    in_stock = request.GET.get("in_stock") == "1"
    if in_stock:
        products = products.filter(stock__gt=0)

    # เรียงลำดับ
    sort_options = {
        "price_asc": "sale_price",
        "price_desc": "-sale_price",
        "newest": "-created_at",
        "popular": "-popularity",
    }
    sort = request.GET.get("sort", "newest")
    if sort not in sort_options:
        sort = "newest"
    products = products.order_by(sort_options[sort], "-id")

    context = {
        "products": products,
        "q": q,
        "categories": Category.objects.all(),
        "selected_category": category_id,
        "brands": (
            Product.objects.filter(status="active")
            .exclude(brand="")
            .values_list("brand", flat=True)
            .distinct()
            .order_by("brand")
        ),
        "selected_brand": brand,
        "min_price": request.GET.get("min_price", ""),
        "max_price": request.GET.get("max_price", ""),
        "min_rating": min_rating,
        "in_stock": in_stock,
        "sort": sort,
        "has_filter": any(
            [
                q,
                category_id,
                brand,
                request.GET.get("min_price"),
                request.GET.get("max_price"),
                min_rating,
                in_stock,
            ]
        ),
    }
    return render(request, "products/product_list.html", context)


def product_detail(request, pk):
    """หน้ารายละเอียดสินค้า 1 ชิ้น"""
    product = get_object_or_404(Product, pk=pk, status="active")
    in_wishlist = False
    can_review = False
    review_form = None

    if request.user.is_authenticated:
        in_wishlist = Wishlist.objects.filter(user=request.user, product=product).exists()
        # รีวิวได้เฉพาะคนที่เคยซื้อสินค้านี้
        can_review = OrderItem.objects.filter(
            order__user=request.user, product=product
        ).exists()
        if can_review:
            existing = Review.objects.filter(user=request.user, product=product).first()
            review_form = ReviewForm(instance=existing)

    context = {
        "product": product,
        "in_wishlist": in_wishlist,
        "can_review": can_review,
        "review_form": review_form,
        "reviews": product.reviews.select_related("user"),
    }
    return render(request, "products/product_detail.html", context)
    return render(
        request,
        "products/product_detail.html",
        {"product": product, "in_wishlist": in_wishlist},
    )

    

@login_required
@require_POST
def toggle_wishlist(request, pk):
    """กดครั้งแรกเพิ่ม กดอีกครั้งลบออกจากรายการโปรด"""
    product = get_object_or_404(Product, pk=pk, status="active")
    item, created = Wishlist.objects.get_or_create(user=request.user, product=product)
    if created:
        messages.success(request, f"เพิ่ม {product.name} ในรายการโปรดแล้ว")
    else:
        item.delete()
        messages.success(request, f"นำ {product.name} ออกจากรายการโปรดแล้ว")
    return redirect("product_detail", pk=product.pk)


@login_required
def wishlist(request):
    """หน้ารายการโปรดของฉัน"""
    items = Wishlist.objects.filter(user=request.user).select_related("product")
    return render(request, "products/wishlist.html", {"items": items})
    

@login_required
@require_POST
def add_review(request, pk):
    """บันทึกรีวิว (ถ้าเคยรีวิวแล้วจะเป็นการแก้ไขรีวิวเดิม)"""
    product = get_object_or_404(Product, pk=pk, status="active")

    # ตรวจสิทธิ์ฝั่ง Server อีกครั้ง ห้ามเชื่อแค่การซ่อนฟอร์มใน Template
    has_bought = OrderItem.objects.filter(order__user=request.user, product=product).exists()
    if not has_bought:
        messages.error(request, "รีวิวได้เฉพาะสินค้าที่คุณเคยสั่งซื้อ")
        return redirect("product_detail", pk=product.pk)

    existing = Review.objects.filter(user=request.user, product=product).first()
    form = ReviewForm(request.POST, instance=existing)
    if form.is_valid():
        review = form.save(commit=False)
        review.user = request.user
        review.product = product
        review.save()
        messages.success(request, "บันทึกรีวิวเรียบร้อยแล้ว ขอบคุณที่ให้คะแนน")
    else:
        messages.error(request, "ข้อมูลรีวิวไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง")
    return redirect("product_detail", pk=product.pk)