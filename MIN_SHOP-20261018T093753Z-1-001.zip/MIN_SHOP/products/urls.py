from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("products/", views.product_list, name="product_list"),
    path("products/<int:pk>/", views.product_detail, name="product_detail"),
    path("products/<int:pk>/wishlist/", views.toggle_wishlist, name="toggle_wishlist"),
    path("products/<int:pk>/review/", views.add_review, name="add_review"),
    path("wishlist/", views.wishlist, name="wishlist"),
]