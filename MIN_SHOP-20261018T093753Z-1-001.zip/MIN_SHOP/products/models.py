from decimal import Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import Avg
from django.utils import timezone


class Category(models.Model):
    """หมวดหมู่สินค้า เช่น เสื้อผ้า, รองเท้า"""

    name = models.CharField("ชื่อหมวดหมู่", max_length=100, unique=True)
    created_at = models.DateTimeField("วันที่สร้าง", auto_now_add=True)

    class Meta:
        verbose_name = "หมวดหมู่"
        verbose_name_plural = "หมวดหมู่"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Product(models.Model):
    """สินค้า"""

    STATUS_CHOICES = [
        ("active", "วางขาย"),
        ("inactive", "ปิดขาย"),
    ]

    name = models.CharField("ชื่อสินค้า", max_length=200)
    description = models.TextField("รายละเอียด", blank=True)
    price = models.DecimalField(
        "ราคา",
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0"))],
    )
    discount = models.PositiveIntegerField(
        "ส่วนลด (%)",
        default=0,
        validators=[MaxValueValidator(100)],
    )
    stock = models.PositiveIntegerField("จำนวนในสต็อก", default=0)
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        related_name="products",
        verbose_name="หมวดหมู่",
    )
    brand = models.CharField("แบรนด์", max_length=100, blank=True)
    image = models.ImageField("รูปสินค้า", upload_to="products/", blank=True)
    status = models.CharField(
        "สถานะ", max_length=10, choices=STATUS_CHOICES, default="active"
    )
    created_at = models.DateTimeField("วันที่สร้าง", auto_now_add=True)
    updated_at = models.DateTimeField("วันที่แก้ไขล่าสุด", auto_now=True)

    class Meta:
        verbose_name = "สินค้า"
        verbose_name_plural = "สินค้า"
        ordering = ["-created_at"]

    def __str__(self):
        return self.name

    @property
    def final_price(self):
        """ราคาหลังหักส่วนลด"""
        return round(self.price * (100 - self.discount) / 100, 2)
        
    @property
    def average_rating(self):
        """คะแนนเฉลี่ย (ปัดเป็นทศนิยม 1 ตำแหน่ง) ถ้ายังไม่มีรีวิวคืนค่า None"""
        result = self.reviews.aggregate(avg=Avg("rating"))["avg"]
        return round(result, 1) if result else None

    @property
    def review_count(self):
        """จำนวนรีวิว"""
        return self.reviews.count()

        

class Wishlist(models.Model):
    """รายการโปรด: ผู้ใช้ 1 คน + สินค้า 1 ชิ้น"""

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="wishlist_items",
        verbose_name="ผู้ใช้",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name="wishlisted_by",
        verbose_name="สินค้า",
    )
    created_at = models.DateTimeField("วันที่เพิ่ม", auto_now_add=True)

    class Meta:
        verbose_name = "รายการโปรด"
        verbose_name_plural = "รายการโปรด"
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["user", "product"], name="unique_wishlist_per_user_product"
            )
        ]

    def __str__(self):
        return f"{self.user.username} ♥ {self.product.name}"

        

class Review(models.Model):
    """รีวิวและคะแนนสินค้า"""

    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name="reviews",
        verbose_name="สินค้า",
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="reviews",
        verbose_name="ผู้รีวิว",
    )
    rating = models.PositiveSmallIntegerField(
        "คะแนน (1-5)",
        validators=[MinValueValidator(1), MaxValueValidator(5)],
    )
    comment = models.TextField("ความคิดเห็น", blank=True)
    created_at = models.DateTimeField("วันที่รีวิว", auto_now_add=True)

    class Meta:
        verbose_name = "รีวิว"
        verbose_name_plural = "รีวิว"
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["user", "product"], name="unique_review_per_user_product"
            )
        ]

    def __str__(self):
        return f"{self.user.username} ให้ {self.product.name} {self.rating} ดาว"

        

class Promotion(models.Model):
    """โปรโมชัน / แคมเปญ Flash Sale: กำหนดสินค้าและช่วงเวลา"""

    title = models.CharField("ชื่อโปรโมชัน", max_length=150)
    description = models.TextField("รายละเอียด", blank=True)
    products = models.ManyToManyField(
        Product,
        related_name="promotions",
        blank=True,
        verbose_name="สินค้าในโปรโมชัน",
    )
    start_at = models.DateTimeField("เริ่มต้น")
    end_at = models.DateTimeField("สิ้นสุด")
    is_active = models.BooleanField("เปิดใช้งาน", default=True)
    created_at = models.DateTimeField("วันที่สร้าง", auto_now_add=True)

    class Meta:
        verbose_name = "โปรโมชัน"
        verbose_name_plural = "โปรโมชัน"
        ordering = ["-start_at"]

    def __str__(self):
        return self.title

    def clean(self):
        # Validation: เวลาสิ้นสุดต้องหลังเวลาเริ่มต้น
        if self.start_at and self.end_at and self.end_at <= self.start_at:
            raise ValidationError("เวลาสิ้นสุดต้องอยู่หลังเวลาเริ่มต้น")

    @property
    def is_running(self):
        """กำลังอยู่ในช่วงโปรโมชันหรือไม่"""
        now = timezone.now()
        return self.is_active and self.start_at <= now <= self.end_at