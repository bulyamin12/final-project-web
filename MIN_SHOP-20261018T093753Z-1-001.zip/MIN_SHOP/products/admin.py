from django.contrib import admin

from .models import Category, Product, Promotion, Review, Wishlist

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "created_at")
    search_fields = ("name",)
    ordering = ("name",)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "brand", "price", "discount", "stock", "status", "created_at")
    list_filter = ("category", "status", "brand")
    search_fields = ("name", "brand", "description")
    ordering = ("-created_at",)
    list_editable = ("price", "stock", "status")

    
@admin.register(Wishlist)
class WishlistAdmin(admin.ModelAdmin):
    list_display = ("user", "product", "created_at")
    search_fields = ("user__username", "product__name")

    
@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ("product", "user", "rating", "created_at")
    list_filter = ("rating", "created_at")
    search_fields = ("product__name", "user__username", "comment")
    

@admin.register(Promotion)
class PromotionAdmin(admin.ModelAdmin):
    list_display = ("title", "start_at", "end_at", "is_active", "is_running")
    list_filter = ("is_active", "start_at")
    search_fields = ("title", "description")
    filter_horizontal = ("products",)
    ordering = ("-start_at",)

    @admin.display(boolean=True, description="กำลังดำเนินการ")
    def is_running(self, obj):
        return obj.is_running