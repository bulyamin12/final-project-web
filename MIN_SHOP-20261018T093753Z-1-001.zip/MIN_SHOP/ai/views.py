import json

from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_POST

from .services import ask_assistant


@login_required
def chat_page(request):
    """หน้าแชตผู้ช่วยช้อปปิ้ง"""
    return render(request, "ai/chat.html")


@login_required
@require_POST
def chat_api(request):
    """รับคำถามเป็น JSON แล้วตอบกลับเป็น JSON"""
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"error": "รูปแบบข้อมูลไม่ถูกต้อง"}, status=400)

    message = str(data.get("message", "")).strip()
    if not message:
        return JsonResponse({"error": "กรุณาพิมพ์ข้อความ"}, status=400)

    answer, source = ask_assistant(message)
    return JsonResponse({"answer": answer, "source": source})