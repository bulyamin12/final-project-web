from django.conf import settings

from products.models import Product

# จำกัดจำนวนสินค้าที่ส่งให้ AI เพื่อประหยัดค่าใช้จ่าย
MAX_PRODUCTS_IN_PROMPT = 30
MAX_MESSAGE_LENGTH = 500

SYSTEM_PROMPT = (
    "คุณคือผู้ช่วยช้อปปิ้งของร้าน MIN SHOP ตอบเป็นภาษาไทย สุภาพ กระชับ "
    "แนะนำสินค้าได้เฉพาะจากรายการสินค้าที่ให้มาเท่านั้น ห้ามแต่งสินค้าหรือราคาขึ้นเอง "
    "ถ้าไม่มีสินค้าที่ตรงกับความต้องการ ให้บอกตรง ๆ ว่าตอนนี้ยังไม่มี "
    "แนะนำไม่เกิน 3 รายการ พร้อมบอกชื่อ ราคา และเหตุผลสั้น ๆ"
)


def get_active_products():
    """สินค้าที่วางขายและมีสต็อก"""
    return Product.objects.filter(status="active", stock__gt=0).select_related(
        "category"
    )[:MAX_PRODUCTS_IN_PROMPT]


def build_product_context(products):
    """แปลงรายการสินค้าเป็นข้อความ เพื่อแนบไปกับ Prompt"""
    lines = []
    for p in products:
        lines.append(
            f"- {p.name} | หมวด: {p.category.name} | แบรนด์: {p.brand or '-'} "
            f"| ราคา: {p.final_price} บาท | เหลือ: {p.stock} ชิ้น"
        )
    return "\n".join(lines)


def fallback_answer(message, products):
    """โหมดสำรอง: ค้นสินค้าจากคำสำคัญ (ไม่ใช้ AI)"""
    msg = message.lower()
    matched = []
    for p in products:
        # คำสำคัญของสินค้า: ชื่อ หมวด แบรนด์
        keywords = [p.name, p.category.name, p.brand]
        if any(k and k.lower() in msg for k in keywords):
            matched.append(p)

    if not matched:
        return "ขออภัยครับ ตอนนี้ยังไม่พบสินค้าที่ตรงกับที่คุณต้องการ ลองบอกประเภทสินค้าหรือแบรนด์ที่สนใจได้เลยครับ"

    lines = ["สินค้าที่อาจตรงกับที่คุณมองหา:"]
    for p in matched[:3]:
        lines.append(f"- {p.name} ราคา {p.final_price} บาท (เหลือ {p.stock} ชิ้น)")
    return "\n".join(lines)


def ask_assistant(message):
    """
    รับคำถามลูกค้า คืนค่า (คำตอบ, แหล่งที่มา)
    แหล่งที่มา = "ai" หรือ "fallback"
    """
    message = message.strip()[:MAX_MESSAGE_LENGTH]
    products = list(get_active_products())

    # ไม่มี API Key -> ใช้โหมดสำรอง
    if not settings.OPENAI_API_KEY:
        return fallback_answer(message, products), "fallback"

    try:
        # import ในฟังก์ชัน เพื่อให้เว็บรันได้แม้ไม่ได้ติดตั้งไลบรารี
        from openai import OpenAI

        client = OpenAI(api_key=settings.OPENAI_API_KEY, timeout=20)
        response = client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "system",
                    "content": "รายการสินค้าในร้าน:\n" + build_product_context(products),
                },
                {"role": "user", "content": message},
            ],
            max_tokens=400,
        )
        answer = response.choices[0].message.content
        return answer, "ai"
    except Exception:
        # เรียก AI ไม่สำเร็จ (เน็ต, Key ผิด, เครดิตหมด ฯลฯ) -> ใช้โหมดสำรอง
        return fallback_answer(message, products), "fallback"